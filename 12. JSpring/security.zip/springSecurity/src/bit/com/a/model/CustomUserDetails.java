package bit.com.a.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;	//상속

/*
DROP TABLE USERTABLE 
CASCADE CONSTRAINTS;

CREATE TABLE USERTABLE(
    ID VARCHAR2(100) PRIMARY KEY,
    PASSWORD VARCHAR2(300) NOT NULL,
    NAME VARCHAR2(45) NOT NULL,
    AUTHORITY VARCHAR2(50) NOT NULL,
    ENABLED NUMBER(1)
);

INSERT INTO USERTABLE(ID, PASSWORD, NAME, AUTHORITY, ENABLED)
VALUES('aaa', '12qw12qw', 'kdw', 'ROLE_USER', 1); 

INSERT INTO USERTABLE(ID, PASSWORD, NAME, AUTHORITY, ENABLED)
VALUES('bbb', '12qw12qw', 'dwk', 'ROLE_MEMBER', 1); 

INSERT INTO USERTABLE(ID, PASSWORD, NAME, AUTHORITY, ENABLED)
VALUES('ccc', '12qw12qw', 'wkd', 'ROLE_ADMIN', 1); 

COMMIT;
*/

//dto == vo == model 명명
public class CustomUserDetails implements UserDetails, Serializable {

	//대문자 확인!!!
	private String ID;			
	private String PASSWORD;
	private String NAME;
	// 필요시 column 추가
	private String AUTHORITY;	// 권한  1, 3 (int) 와 달리 권한 1 12 123 하나씩 내포하고 늘어나는
	private boolean	ENABLED;	// 접근 가능 여부
	
	public CustomUserDetails() {
	
	}

	@Override	//GrantedAuthority 허가, 권리		
	public Collection<? extends GrantedAuthority> getAuthorities() {	//getAuthorities 권한들을 return
		//컬렉션으로 만들어진 이유? 권한 설정이 될 수 있기 때문에
	
		ArrayList<GrantedAuthority> auth = new ArrayList<GrantedAuthority>();
		auth.add(new SimpleGrantedAuthority(AUTHORITY));				//여러 권한 들을 리스트로 모아준 것
		
		return auth;
	}

	@Override
	public String getPassword() {
		return PASSWORD;
	}

	@Override
	public String getUsername() {				// id == name
		return ID;
	}

	@Override
	public boolean isAccountNonExpired() {		// 계정이 만료된 계정인지
		return true;	//만료 안됐다는
	}

	@Override
	public boolean isAccountNonLocked() {		// 계정이 잠겨 있는지
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {	// 계정의 패스워드가 만료되지 않았는지
		return true;
	}

	@Override
	public boolean isEnabled() {				// 사용 가능 여부
		return true;							// cf) 아예 닫아놓게 설정 업데이트 같은거????????????????????????????
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}
	
	
}
