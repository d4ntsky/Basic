package bit.com.a.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import bit.com.a.dao.CustomUserDao;
import bit.com.a.model.CustomUserDetails;

public class CustomUserService implements UserDetailsService {

	@Autowired
	CustomUserDao dao;
	
	@Override			//호출하는 부분은 따로 있음???????????????????????????
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		System.out.println("CustomUserService loadUserByUsername()의 호출");
		
		//--------------------------------------------------------------------------------------
		//서비스를 따로 갖고 가게 만들어져 있어 서비스와 컨트롤러의 대화를 막아놓고 독자적으로 호출하여 사용 -- 보안의 핵심!!!!!!!!!!!!!!
		//loadUserByUsername를 바로 호출하는게 아니라 CustomUserService(보안의 주인공)이 
		
		CustomUserDetails user = dao.getUserById(username);
		if(user == null) {
			throw new UsernameNotFoundException(username);	// 오류 확인용
		}
		
		return user;
	}

}
