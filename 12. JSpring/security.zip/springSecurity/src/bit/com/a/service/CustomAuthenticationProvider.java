package bit.com.a.service;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;

import bit.com.a.model.CustomUserDetails;

//나야나
public class CustomAuthenticationProvider implements AuthenticationProvider {	//Authentication 확증 Provider 제공


	private static Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
	
	@Autowired	//서비스의 CustomUserService //cf)스프링에선 2차 상속이 되지 않는다!!!!!!!!!!!!!!!!!
	private UserDetailsService userDeSer;
	
	public boolean matchPassword(String loginPwd, String password) {
		logger.info("CustomAuthenticationProvider matchPassword() 체크");
		return loginPwd.equals(password);
	}
	
	@SuppressWarnings("unchecked")	//점검???????????????????????????????????????????????????????
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {	//인증 함수
		
		// 입력된 정보가 넘어왔는지 확인
		String username = (String)authentication.getPrincipal();	// id : return값이 object임
		String password = (String)authentication.getCredentials();	// pwd 

		logger.info("CustomAuthenticationProvider authenticate");
		logger.info("입력한 id : " + username);
		logger.info("입력한 pw : " + password);
		
		// DB로부터 온 정보
		CustomUserDetails user = (CustomUserDetails)userDeSer.loadUserByUsername(username);				// dao 통해 가져온것
		Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>)user.getAuthorities(); // ROLE_... 이거 가져오는
		System.out.println("넘어온 권한"+authorities);
		
		if(!matchPassword(password, user.getPassword())) {	//패스워드가 틀린 경우
			throw new BadCredentialsException(username);
		}

		if(!user.isEnabled()) {
			throw new BadCredentialsException(username);
		}
		
		return new UsernamePasswordAuthenticationToken(username, password, authorities);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		return true;	//뭐가 true임?
	}

}
